import './App.css';
import HomeNavbar from './Component/HomeNavbar';
import Footer from './Component/Footer';
import Navbar from './Component/Navbar';
import Login from './Component/Login';

function App() {
  return (
    <div className="App">
      {/* <Navbar/> */}
      <HomeNavbar/>
      <Login/>
      <Footer/>
    </div>
  );
}

export default App;
